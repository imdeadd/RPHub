Config = {}

Config.APIKey = 'twoj-wygenerowany-klucz-api'

Config.BackendURL = 'http://localhost:3000'

Config.ServerIP = nil

Config.Cooldown = 60

Config.Debug = true