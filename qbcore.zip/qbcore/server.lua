local QBCore = exports['qb-core']:GetCoreObject()
local cooldowns = {}
local isVerified = false
local API_KEY = Config.APIKey
local SERVER_IP = Config.ServerIP or GetConvar('sv_endpointprivacy', 'localhost').gsub(':30120', '')

CreateThread(function()
    MySQL.query.await('CREATE TABLE IF NOT EXISTS selly_rewards (id INT AUTO_INCREMENT PRIMARY KEY, citizenid VARCHAR(50), item VARCHAR(50), amount INT, status VARCHAR(20), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)')
    print('^2[Selly] Database initialized^7')
end)

function VerifyApiKey()
    local url = Config.BackendURL .. '/api/verify-key/fivem'
    local data = {
        apiKey = API_KEY,
        serverIp = SERVER_IP
    }
    
    PerformHttpRequest(url, function(err, text, headers)
        if err == 200 then
            local result = json.decode(text)
            if result.valid then
                isVerified = true
                print('^2[Selly] Klucz API zweryfikowany pomyślnie! Serwer: ' .. result.serverName .. '^7')
            else
                isVerified = false
                print('^1[Selly] Błąd weryfikacji: ' .. (result.error or 'Nieznany błąd') .. '^7')
            end
        else
            isVerified = false
            print('^1[Selly] Nie udało się połączyć z backendem (HTTP ' .. err .. ')^7')
        end
    end, 'POST', json.encode(data), {['Content-Type'] = 'application/json'})
end

CreateThread(function()
    Wait(5000)
    VerifyApiKey()
    
    setInterval(function()
        if not isVerified then
            VerifyApiKey()
        end
    end, 300000)
end)

function GetPlayerByIdentifier(identifier)
    local players = QBCore.Functions.GetQBPlayers()
    for _, player in pairs(players) do
        if player.PlayerData.steam == identifier or player.PlayerData.citizenid == identifier or string.lower(player.PlayerData.name) == string.lower(identifier) then
            return player
        end
    end
    return nil
end

function GiveReward(source, rewardData)
    if not isVerified then
        print('^1[Selly] Klucz API niezweryfikowany, odrzucam nagrodę^7')
        return false
    end
    
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return false end
    
    local citizenid = Player.PlayerData.citizenid
    
    if cooldowns[citizenid] and (os.time() - cooldowns[citizenid]) < Config.Cooldown then
        TriggerClientEvent('ox_lib:notify', source, {title = 'Selly', description = 'Proszę zaczekaj przed odebraniem kolejnej nagrody', type = 'error'})
        return false
    end
    
    if rewardData.fivemMoneyAmount and rewardData.fivemMoneyAmount > 0 then
        Player.Functions.AddMoney('cash', rewardData.fivemMoneyAmount)
        TriggerClientEvent('ox_lib:notify', source, {title = 'Selly', description = string.format('Otrzymałeś $%d', rewardData.fivemMoneyAmount), type = 'success'})
    end
    
    if rewardData.fivemItem and rewardData.fivemItemAmount then
        Player.Functions.AddItem(rewardData.fivemItem, rewardData.fivemItemAmount)
        TriggerClientEvent('ox_lib:notify', source, {title = 'Selly', description = string.format('Otrzymałeś %dx %s', rewardData.fivemItemAmount, rewardData.fivemItem), type = 'success'})
    end
    
    if rewardData.fivemJob then
        local jobData = QBShared.Jobs[rewardData.fivemJob]
        if jobData then
            Player.Functions.SetJob(rewardData.fivemJob, 0)
            TriggerClientEvent('ox_lib:notify', source, {title = 'Selly', description = string.format('Twoja praca została zmieniona na %s', jobData.label), type = 'success'})
        end
    end
    
    cooldowns[citizenid] = os.time()
    
    MySQL.query('INSERT INTO selly_rewards (citizenid, item, amount, status) VALUES (?, ?, ?, ?)', {
        citizenid,
        rewardData.fivemItem or 'money',
        rewardData.fivemItemAmount or rewardData.fivemMoneyAmount or 0,
        'delivered'
    })
    
    return true
end

RegisterNetEvent('selly:giveReward')
AddEventHandler('selly:giveReward', function(data)
    local src = source
    GiveReward(src, data.rewardData)
end)

RegisterNetEvent('selly:giveRewardByIdentifier')
AddEventHandler('selly:giveRewardByIdentifier', function(data)
    if not isVerified then
        print('^1[Selly] Klucz API niezweryfikowany^7')
        return
    end
    local target = GetPlayerByIdentifier(data.identifier)
    if target then
        GiveReward(target.PlayerData.source, data.rewardData)
    end
end)

RegisterCommand('testreward', function(source, args)
    local reward = {
        fivemMoneyAmount = 1000,
        fivemItem = 'bread',
        fivemItemAmount = 5
    }
    GiveReward(source, reward)
end, false)

exports('GiveReward', GiveReward)
exports('GetPlayerByIdentifier', GetPlayerByIdentifier)
exports('IsVerified', function() return isVerified end)

print('^2[Selly] FiveM script loaded successfully^7')