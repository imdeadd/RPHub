fx_version 'cerulean'
game 'gta5'
author 'D3ad'

author 'Selly'
description 'Selly FiveM Integration'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua',
    'config.lua'
}

client_scripts {
    'client.lua'
}

dependencies {
    'qb-core',
    'oxmysql'
}