local QBCore = exports['qb-core']:GetCoreObject()

-- Client-side notification handler
RegisterNetEvent('panelpay:notify')
AddEventHandler('panelpay:notify', function(message, type)
    if type == 'success' then
        QBCore.Functions.Notify(message, 'success')
    elseif type == 'error' then
        QBCore.Functions.Notify(message, 'error')
    else
        QBCore.Functions.Notify(message, 'primary')
    end
end)

-- Optional: UI for rewards (if you want to show a menu)
RegisterCommand('shop', function()
    QBCore.Functions.Notify('Visit our store at: https://panelpay.gg/your-store', 'info')
end, false)

print('^2[PanelPay] Client script loaded^7')