local ESX = nil
local cooldowns = {}
local isVerified = false
local API_KEY = Config.APIKey
local SERVER_IP = Config.ServerIP or GetConvar('sv_endpointprivacy', 'localhost'):gsub(':30120', '')

CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(100)
    end
    
    MySQL.query.await('CREATE TABLE IF NOT EXISTS selly_rewards (id INT AUTO_INCREMENT PRIMARY KEY, identifier VARCHAR(50), item VARCHAR(50), amount INT, status VARCHAR(20), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)')
    print('^2[Selly ESX] Database initialized^7')
end)

function VerifyApiKey()
    local url = Config.BackendURL .. '/api/verify-key/fivem'
    local data = {
        apiKey = API_KEY,
        serverIp = SERVER_IP
    }
    
    PerformHttpRequest(url, function(err, text, headers)
        if err == 200 then
            local result = json.decode(text)
            if result.valid then
                isVerified = true
                print('^2[Selly ESX] Klucz API zweryfikowany pomyślnie! Serwer: ' .. result.serverName .. '^7')
            else
                isVerified = false
                print('^1[Selly ESX] Błąd weryfikacji: ' .. (result.error or 'Nieznany błąd') .. '^7')
            end
        else
            isVerified = false
            print('^1[Selly ESX] Nie udało się połączyć z backendem (HTTP ' .. err .. ')^7')
        end
    end, 'POST', json.encode(data), {['Content-Type'] = 'application/json'})
end

CreateThread(function()
    Wait(5000)
    VerifyApiKey()
    
    while true do
        Wait(300000)
        if not isVerified then
            VerifyApiKey()
        end
    end
end)

function GetPlayerByIdentifier(identifier)
    local players = ESX.GetPlayers()
    for _, playerId in ipairs(players) do
        local xPlayer = ESX.GetPlayerFromId(playerId)
        if xPlayer then
            if xPlayer.identifier == identifier or string.lower(xPlayer.getName()) == string.lower(identifier) then
                return xPlayer
            end
        end
    end
    return nil
end

function GiveReward(player, rewardData)
    if not isVerified then
        print('^1[Selly ESX] Klucz API niezweryfikowany, odrzucam nagrodę^7')
        return false
    end
    
    if not player then return false end
    
    local identifier = player.identifier
    
    if cooldowns[identifier] and (os.time() - cooldowns[identifier]) < Config.Cooldown then
        player.showNotification('Proszę zaczekaj przed odebraniem kolejnej nagrody', 'error')
        return false
    end
    
    if rewardData.fivemMoneyAmount and rewardData.fivemMoneyAmount > 0 then
        player.addMoney(rewardData.fivemMoneyAmount)
        player.showNotification(string.format('Otrzymałeś $%d', rewardData.fivemMoneyAmount), 'success')
    end
    
    if rewardData.fivemItem and rewardData.fivemItemAmount then
        player.addInventoryItem(rewardData.fivemItem, rewardData.fivemItemAmount)
        player.showNotification(string.format('Otrzymałeś %dx %s', rewardData.fivemItemAmount, rewardData.fivemItem), 'success')
    end
    
    if rewardData.fivemJob then
        player.setJob(rewardData.fivemJob, 0)
        player.showNotification(string.format('Twoja praca została zmieniona na %s', rewardData.fivemJob), 'success')
    end
    
    cooldowns[identifier] = os.time()
    
    MySQL.query('INSERT INTO selly_rewards (identifier, item, amount, status) VALUES (?, ?, ?, ?)', {
        identifier,
        rewardData.fivemItem or 'money',
        rewardData.fivemItemAmount or rewardData.fivemMoneyAmount or 0,
        'delivered'
    })
    
    return true
end

RegisterNetEvent('selly:giveReward')
AddEventHandler('selly:giveReward', function(data)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if xPlayer then
        GiveReward(xPlayer, data.rewardData)
    end
end)

RegisterNetEvent('selly:giveRewardByIdentifier')
AddEventHandler('selly:giveRewardByIdentifier', function(data)
    if not isVerified then
        print('^1[Selly ESX] Klucz API niezweryfikowany^7')
        return
    end
    local target = GetPlayerByIdentifier(data.identifier)
    if target then
        GiveReward(target, data.rewardData)
    end
end)

ESX.RegisterCommand('testreward', 'admin', function(xPlayer, args, showError)
    local reward = {
        fivemMoneyAmount = 1000,
        fivemItem = 'bread',
        fivemItemAmount = 5
    }
    GiveReward(xPlayer, reward)
end, false, { help = 'Test nagrody Selly' })

exports('GiveReward', GiveReward)
exports('GetPlayerByIdentifier', GetPlayerByIdentifier)
exports('IsVerified', function() return isVerified end)

print('^2[Selly ESX] Script loaded successfully^7')